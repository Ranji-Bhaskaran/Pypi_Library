# __init__.py
from .returncalculator import calculate_returns, calculate_stamp_duty, calculate_admin_fee, calculate_total_cost
